from fastapi import FastAPI
from pydantic import BaseModel
import json
from groq import Groq
from dotenv import load_dotenv
import os

load_dotenv()

client = Groq(api_key=os.getenv("GROQ_API_KEY"))

app = FastAPI()

# Load predefined Q&A database file
json_file = "mentoring_data.json"

# Function to load Q&A database
def load_qna_db():
    try:
        with open(json_file, "r") as file:
            return json.load(file)
    except FileNotFoundError:
        return {}

qna_db = load_qna_db()

# Leave application storage file
leave_file = "leave_applications.json"

# Load existing leave applications (or create an empty file if not found)
try:
    with open(leave_file, "r") as file:
        leave_db = json.load(file)
except FileNotFoundError:
    leave_db = []

# Request format for mentorship queries
class Enquiry(BaseModel):
    content: str

# Request format for adding Q&A
class AddQA(BaseModel):
    question: str
    answer: str

# Request format for leave applications
class LeaveRequest(BaseModel):
    mentor_name: str
    date: str
    reason: str

@app.get("/")
def read_root():
    return {"Welcome": "This is the AI Mentoring Agent powered by Groq!"}

@app.post("/mentor/")
def mentoring_agent(enquiry: Enquiry) -> dict:
    input_text = enquiry.content

    # 1️⃣ Check predefined Q&A first
    if input_text in qna_db:
        return {"response": qna_db[input_text]}

    # 2️⃣ If not found, call Groq AI
    response = client.chat.completions.create(
        model="llama3-8b-8192",
        messages=[
            {"role": "system",
             "content": "You are an AI Mentoring Agent providing career guidance, motivation, and study advice. Keep responses concise."},
            {"role": "user", "content": input_text}
        ]
    )
    return {"response": response.choices[0].message.content}

@app.post("/apply_leave/")
def apply_leave(request: LeaveRequest) -> dict:
    """Mentors can apply for leave here."""
    leave_db.append({
        "mentor_name": request.mentor_name,
        "date": request.date,
        "reason": request.reason
    })

    # Save the leave request to the file
    with open(leave_file, "w") as file:
        json.dump(leave_db, file, indent=4)

    return {"message": f"Leave request submitted for {request.mentor_name} on {request.date}"}

@app.get("/view_leaves/")
def view_leaves() -> dict:
    """View all leave applications"""
    return {"leave_requests": leave_db}

@app.post("/add_qa/")
def add_question_answer(qa: AddQA):
    """API to add new questions and answers to the JSON database"""
    qna_db[qa.question] = qa.answer
    
    # Save updated data to JSON file
    with open(json_file, "w") as file:
        json.dump(qna_db, file, indent=4)
    
    return {"message": "New Q&A added successfully!", "question": qa.question, "answer": qa.answer}

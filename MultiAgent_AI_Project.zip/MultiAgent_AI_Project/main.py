from fastapi import FastAPI
from pydantic import BaseModel
import requests

app = FastAPI()

MENTORING_AGENT_URL = "http://127.0.0.1:8000/mentor/"  # Update this if running on a different port

class Enquiry(BaseModel):
    content: str

@app.get("/")
def read_root():
    return {"Welcome": "This is the main entry point for the AI Mentoring Chatbot."}

@app.post("/mentor/")
def mentor_user(enquiry: Enquiry) -> dict:
    """Calls the Mentoring Agent to provide guidance and advice."""
    try:
        response = requests.post(MENTORING_AGENT_URL, json={"content": enquiry.content})
        return response.json()
    except Exception as e:
        return {"error": str(e)}


import streamlit as st
import requests

# Streamlit UI
st.set_page_config(page_title="AI Mentor Chatbot", page_icon="🤖")
st.title("🧑‍🏫 AI Mentoring Agent")
st.write("Ask any career or study-related question!")

# API endpoints
MENTOR_API_URL = "http://127.0.0.1:8000/mentor/"  
LEAVE_API_URL = "http://127.0.0.1:8000/apply_leave/"
VIEW_LEAVE_API_URL = "http://127.0.0.1:8000/view_leaves/"

# --- MENTORING SECTION ---
st.header("💡 Ask for Mentorship Advice")
user_input = st.text_area("Enter your question:")

if st.button("Get Advice"):
    if user_input.strip():
        with st.spinner("Thinking... 🤔"):
            response = requests.post(MENTOR_API_URL, json={"content": user_input})
            if response.status_code == 200:
                reply = response.json().get("response", "Error: No response received.")
                st.success("🤖 AI Mentor's Advice:")
                st.write(reply)
            else:
                st.error("Error: Could not connect to AI Mentor. Check API.")
    else:
        st.warning("Please enter a question first.")

# --- LEAVE APPLICATION SECTION ---
st.header("📅 Apply for Leave")

mentor_name = st.text_input("👤 Mentor Name")
leave_date = st.date_input("📆 Leave Date")
leave_reason = st.text_area("✍️ Reason for Leave")

if st.button("Submit Leave Request"):
    if mentor_name and leave_date and leave_reason.strip():
        with st.spinner("Submitting leave request... ⏳"):
            leave_data = {
                "mentor_name": mentor_name,
                "date": leave_date.strftime("%Y-%m-%d"),
                "reason": leave_reason
            }
            response = requests.post(LEAVE_API_URL, json=leave_data)
            if response.status_code == 200:
                st.success(response.json().get("message", "Leave request submitted!"))
            else:
                st.error("Error: Could not submit leave request.")
    else:
        st.warning("Please fill in all fields.")

# --- VIEW LEAVE REQUESTS ---
st.header("📋 View Leave Applications")

if st.button("Show Leave Requests"):
    with st.spinner("Fetching leave data... ⏳"):
        response = requests.get(VIEW_LEAVE_API_URL)
        if response.status_code == 200:
            leave_data = response.json().get("leave_requests", [])
            if leave_data:
                for leave in leave_data:
                    st.write(f"👤 **{leave['mentor_name']}** | 📅 {leave['date']} | ✍️ {leave['reason']}")
            else:
                st.info("No leave applications found.")
        else:
            st.error("Error fetching leave applications.")
